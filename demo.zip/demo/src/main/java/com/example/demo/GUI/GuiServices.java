package com.example.demo.GUI;

import com.example.demo.DemoApplication;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class GuiServices {
    public String lu_form;
    public double[] g_initial_guess_values;
    public double g_stop_value; // value
    public String g_stop_condition; //choice
    public int g_precision;
    public String text;
    public String[] manner;
    public boolean attributesFlag = false;
    public double xu_value;
    public double xl_value;
    public double error;
    public int type;
    public int noOfiterations;
    public double initial;
    public String equation;

    public GuiServices() {
        lu_form = "Doolittle Form";
        g_stop_value = 50;
        g_stop_condition = "Number of Iterations";
        g_precision = -1;
        text = "Gauss Elimination";
        manner = new String[]{"Gauss Elimination", "Gauss-Jordan", "LU Decomposition", "Gauss-Seidil", "Jacobi-Iteration", "Bisection", "False-Position", "Fixed Point", "Newton-Raphson", "Secant Method"};
        xu_value = 2;
        xl_value = 1;
        error = 0.00001;
        type = 1;
        noOfiterations = 50;
        initial = 0;
    }

    //Variables.setEditable(false);
    public int checkType(String input) {
        if (input.equals("Gauss Elimination") || input.equals("Gauss-Jordan") || input.equals("LU Decomposition") || input.equals("Gauss-Seidil") || input.equals("Jacobi-Iteration")) {
            return 1;
        } else {
            return 2;
        }
    }

    public double[][] getCoefficientMatrix(double[][] matrix, int n) {
        if (!attributesFlag) {
            g_initial_guess_values = new double[n];
            for (int i = 0; i < n; i++) {
                g_initial_guess_values[i] = 0;
            }
            attributesFlag = false;
        }
        double[][] coefficient = new double[n][n];
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                coefficient[i][j] = matrix[i][j];
            }
        }
        return coefficient;
    }

    public double[] getResultsArray(double[][] matrix, int n) {
        double[] results = new double[n];
        for (int i = 0; i < n; i++) {
            results[i] = matrix[i][n];
        }
        return results;
    }

    public double[] separate(String n) {
        try {
            String[] array = n.split(", ");
            double[] values = new double[array.length];
            for (int i = 0; i < array.length; i++) {
                values[i] = checkNumber_double(array[i]);
            }
            return values;
        } catch (Exception e) {
            showError("Enter numbers Separated by \", \"");
        }
        return null;
    }

    public double checkNumber_double(String n) {
        try {
            return Double.parseDouble(n);
        } catch (NumberFormatException e) {
            showError("Please, Enter a valid number");
        }
        return 0;
    }

    public void showError(String message) {
        JDialog error = new JDialog();
        String path = "src/main/resources/Logo.png";
        ImageIcon image = new ImageIcon(path);

        JLabel label = new JLabel();
        JButton b = new JButton("OK");
        String path2 = "src/main/resources/Error.png";


        ImageIcon icon = new ImageIcon(path2);
        JLabel icon_label = new JLabel(icon);
        b.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                error.setVisible(false);
            }
        });
        error.setIconImage(image.getImage());
        label.setText(message);
        label.setFont(new Font("Times New Roman", Font.PLAIN, 30));
        label.setBounds(80, 150, 400, 50);
        b.setFont(new Font("Times New Roman", Font.PLAIN, 20));
        b.setBounds(200, 200, 100, 50);
        b.setBackground(Color.green);
        icon_label.setHorizontalAlignment(JLabel.CENTER);
        icon_label.setVerticalAlignment(JLabel.TOP);
        error.add(b);
        error.add(label);
        error.add(icon_label);
        error.setSize(500, 300);
        error.setVisible(true);
        error.getContentPane().setBackground(Color.decode("#878f99"));
        error.setLocationRelativeTo(null);
    }

    public int checkNumber_int(String n) {
        try {
            return Integer.parseInt(n);
        } catch (NumberFormatException e) {
            showError("Please, Enter a valid Integer");
        }
        return 0;
    }

    public String turnIntoString(double[] solution) {
        String res = "";
        for (double i : solution) {
            res = res + i + " ";
        }
        return res;
    }

    public void showParameters(String method) {
        String[] lu = {"Doolittle Form", "Crout Form"};
        String[] iterations = {"Number of Iterations", "Absolute Relative Error"};
        JTextPane precision = new JTextPane();
        JLabel precision_label = new JLabel();
        JLabel l_Dialog = new JLabel();
        JLabel initial_guess_label = new JLabel();
        JButton ok = new JButton("OK");
        JTextField in_dialog = new JTextField();
        JTextField initial_guess = new JTextField();
        JDialog parameter = new JDialog();
        String path = "src/main/resources/Logo.png";
        ImageIcon image = new ImageIcon(path);
        JComboBox lu_dialog = new JComboBox(lu);
        JComboBox iterat = new JComboBox(iterations);

        JLabel xu = new JLabel("Xu");
        JLabel xl = new JLabel("Xl");
        JTextField xu_field = new JTextField();
        JTextField xl_field = new JTextField();

        JLabel no_iterations_label = new JLabel("Itr");
        JLabel error_label = new JLabel("E");
        JTextField no_field = new JTextField();
        JTextField error_field = new JTextField();

        parameter.setIconImage(image.getImage());
        parameter.setTitle("Parameters");
        parameter.setSize(400, 400);

        l_Dialog.setText("Parameter");
        l_Dialog.setForeground(Color.decode("#3e4444"));
        l_Dialog.setFont(new Font("MV Boli", Font.PLAIN, 50));
        l_Dialog.setHorizontalAlignment(JLabel.CENTER);
        l_Dialog.setVerticalAlignment(JLabel.TOP);

        ok.setFont(new Font("Times New Roman", Font.PLAIN, 20));
        ok.setBounds(150, 300, 100, 50);
        ok.setBackground(Color.green);

        lu_dialog.setFont(new Font("Times New Roman", Font.PLAIN, 20));
        lu_dialog.setBounds(100, 200, 200, 50);

        initial_guess_label.setText("Initial Guess");
        initial_guess_label.setFont(new Font("Times New Roman", Font.PLAIN, 30));
        initial_guess_label.setBounds(40, 170, 200, 50);

        iterat.setFont(new Font("Times New Roman", Font.PLAIN, 20));
        iterat.setBounds(40, 240, 200, 50);

        in_dialog.setFont(new Font("Times New Roman", Font.PLAIN, 20));
        in_dialog.setBounds(250, 240, 100, 50);
        in_dialog.setText("50");

        initial_guess.setText("0, 0, 0");
        initial_guess.setFont(new Font("Times New Roman", Font.PLAIN, 20));
        initial_guess.setBounds(250, 170, 100, 50);

        precision_label.setText("Precision");
        precision_label.setFont(new Font("Times New Roman", Font.PLAIN, 30));
        precision_label.setBounds(40, 100, 150, 50);

        precision.setFont(new Font("Times New Roman", Font.PLAIN, 30));
        precision.setBounds(160, 100, 200, 50);

        xu.setFont(new Font("Times New Roman", Font.PLAIN, 30));
        xu.setBounds(40, 170, 50, 50);

        xl.setFont(new Font("Times New Roman", Font.PLAIN, 30));
        xl.setBounds(210, 170, 50, 50);

        xu_field.setFont(new Font("Times New Roman", Font.PLAIN, 30));
        xu_field.setBounds(100, 170, 100, 50);
        xu_field.setText("2");

        xl_field.setFont(new Font("Times New Roman", Font.PLAIN, 30));
        xl_field.setBounds(260, 170, 100, 50);
        xl_field.setText("1");

        no_iterations_label.setFont(new Font("Times New Roman", Font.PLAIN, 30));
        no_iterations_label.setBounds(40, 240, 50, 50);

        error_label.setFont(new Font("Times New Roman", Font.PLAIN, 30));
        error_label.setBounds(210, 240, 50, 50);

        no_field.setFont(new Font("Times New Roman", Font.PLAIN, 30));
        no_field.setBounds(100, 240, 100, 50);
        no_field.setText("50");

        error_field.setFont(new Font("Times New Roman", Font.PLAIN, 30));
        error_field.setBounds(260, 240, 100, 50);
        error_field.setText("0.00001");

        l_Dialog.setVisible(true);
        lu_dialog.setVisible(false);
        initial_guess_label.setVisible(false);
        iterat.setVisible(false);
        in_dialog.setVisible(false);
        initial_guess.setVisible(false);
        precision_label.setVisible(true);
        precision.setVisible(true);
        xu.setVisible(false);
        xu_field.setVisible(false);
        xl.setVisible(false);
        xl_field.setVisible(false);
        no_iterations_label.setVisible(false);
        no_field.setVisible(false);
        error_label.setVisible(false);
        error_field.setVisible(false);


        ok.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                boolean flag = true;
                if (initial_guess.getText() == "") {
                    flag = false;
                } else if (in_dialog.getText().equals("")) {
                    flag = false;
                }
                if (flag) {
                    parameter.setVisible(false);
                    g_stop_condition = (String) iterat.getSelectedItem();
                    if (g_stop_condition.equals("Number of Iterations")) {
                        g_stop_value = checkNumber_int((String) in_dialog.getText());
                    } else if (g_stop_condition.equals("Absolute Relative Error")) {
                        g_stop_value = checkNumber_double((String) in_dialog.getText());
                        System.out.println(g_stop_value);
                    }
                    if (!(initial_guess.getText() == "")) g_initial_guess_values = separate(initial_guess.getText());
                    g_stop_condition = (String) iterat.getSelectedItem();
                    attributesFlag = true;
                    if (!(xu_field.getText() == "")) xu_value = Double.parseDouble(xu_field.getText());
                    if (!(xl_field.getText() == "")) xl_value = Double.parseDouble(xl_field.getText());
                    if (!(error_field.getText() == "")) error = Double.parseDouble(error_field.getText());
                    if (!(precision.getText() == "")) g_precision = Integer.parseInt(precision.getText());
                    else g_precision = -1;
                    if (!(no_field.getText() == "")) noOfiterations = Integer.parseInt(no_field.getText());
                    if (!(initial_guess.getText() == "")) initial = Double.parseDouble(initial_guess.getText());
                }
            }
        });

        switch (method) {
            case "LU Decomposition":
                lu_dialog.setVisible(true);
                lu_form = (String) lu_dialog.getSelectedItem();
                break;
            case "Gauss-Seidil":
            case "Jacobi-Iteration":
                iterat.setVisible(true);
                in_dialog.setVisible(true);
                initial_guess.setVisible(true);
                initial_guess_label.setVisible(true);
                break;
            case "Gauss Elimination":
            case "Gauss-Jordan":
                precision.setBounds(160, 150, 200, 50);
                precision_label.setBounds(40, 150, 150, 50);
                break;
            case "Bisection":
            case "False-Position":
                xu.setVisible(true);
                xu_field.setVisible(true);
                xl.setVisible(true);
                xl_field.setVisible(true);
                iterat.setVisible(true);
                in_dialog.setVisible(true);
                break;
            case "Fixed Point":
            case "Newton-Raphson":
                initial_guess.setText("0");
                initial_guess.setVisible(true);
                initial_guess_label.setVisible(true);
                no_iterations_label.setVisible(true);
                no_field.setVisible(true);
                error_label.setVisible(true);
                error_field.setVisible(true);
                break;
            case "Secant Method":
                initial_guess.setText("0");
                xu.setText("Xi");
                xl.setText("Xj");
                xu.setVisible(true);
                xu_field.setVisible(true);
                xl.setVisible(true);
                xl_field.setVisible(true);
                iterat.setVisible(true);
                in_dialog.setVisible(true);
                break;
        }
        parameter.add(lu_dialog);
        parameter.add(iterat);
        parameter.add(in_dialog);
        parameter.add(precision);
        parameter.add(precision_label);
        parameter.add(initial_guess);
        parameter.add(initial_guess_label);
        parameter.add(xu);
        parameter.add(xu_field);
        parameter.add(xl);
        parameter.add(xl_field);
        parameter.add(no_iterations_label);
        parameter.add(no_field);
        parameter.add(error_label);
        parameter.add(error_field);
        parameter.add(ok);
        parameter.add(l_Dialog);
        parameter.getContentPane().setBackground(Color.decode("#878f99"));
        parameter.setVisible(true);
        parameter.setLocationRelativeTo(null);
    }

    public String setMatrix(double[][] array) {
        StringBuilder matrix = new StringBuilder();
        for (double[] doubles : array) {
            for (int j = 0; j < doubles.length; j++) {
                if (j == doubles.length - 1) {
                    matrix.append(Double.toString(doubles[j]));
                } else {
                    matrix.append(Double.toString(doubles[j])).append(" | ");
                }
            }
            matrix.append("\n").append("-----".repeat(doubles.length)).append("\n");
        }
        return matrix.toString();
    }
}
