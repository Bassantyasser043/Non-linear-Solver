package com.example.demo.Solvers.SolvingSystemOflinearEquations.Gauss;

public interface GaussServiceInterface {
    public double[] Gauss(double[][] A, double[] B, int precision) ;
    public double[] Gauus_jorrdan(double[][] A, double[] B, int precisionV);
}
