package com.example.demo.DifferentiationLibrary.parser.operators.unary.simple;

import com.example.demo.DifferentiationLibrary.parser.nodes.NodeConstant;
import com.example.demo.DifferentiationLibrary.parser.nodes.NodeFactory;
import com.example.demo.DifferentiationLibrary.parser.nodes.NodeNumber;
import com.example.demo.DifferentiationLibrary.parser.operators.unary.NumberOperator;

import java.util.function.Function;

public class Abs extends NumberOperator {

    @Override
    protected Function<NodeNumber, NodeConstant> getFunc() {
        return (num -> NodeFactory.createNodeNumberFrom(Math.abs(num.doubleValue())));
    }

    @Override
    public String[] getAliases() {
        return new String[]{"abs", "absolute"};
    }

    @Override
    public String toLongString() {
        return "aboslute";
    }

    @Override
    public String toString() {
        return "abs";
    }

}
