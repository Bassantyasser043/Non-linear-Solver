package com.example.demo.Solvers.FindingRoots.FalsePosition;

import com.example.demo.Evaluation.EvaluateExpression;
import com.example.demo.GUI.Plot;
import com.example.demo.Solvers.Precision;


public class FalsePosition {


    public static String False_position(String equation, String choice, double value, double lower, double upper, int significant) {
        double point = lower;
        double iteration = 0;
        double Eps = 0;
        //drawing graph of the given function
     //   Plot.table(equation, lower, upper);
        //System.out.print(EvaluateExpression.eval(equation, 0));
        switch (choice) {
            case "Number of Iterations":
                iteration = value;
                break;
            case "Absolute Relative Error":
                Eps = value;
                break;
        }
        if (choice.equals("Number of Iterations")) {
            if (EvaluateExpression.eval(equation, lower) * EvaluateExpression.eval(equation, upper) < 0) {
                for (int i = 0; i < iteration; i++) {
                    double nom = Precision.precision(lower * EvaluateExpression.eval(equation, upper) - upper * EvaluateExpression.eval(equation, lower), significant);
                    double dom = Precision.precision(EvaluateExpression.eval(equation, upper) - EvaluateExpression.eval(equation, lower), significant);
                    point = Precision.precision((nom) / (dom), significant);
                    if (EvaluateExpression.eval(equation, point) * EvaluateExpression.eval(equation, lower) > 0) {
                        lower = point;
                    } else if (EvaluateExpression.eval(equation, point) * EvaluateExpression.eval(equation, lower) < 0) {
                        upper = point;
                    } else {
                        break;
                    }
                }
            } else {
                return "This function has no Roots in this interval";
            }
        } else if (choice.equals("Absolute Relative Error")) {
            if (EvaluateExpression.eval(equation, lower) * EvaluateExpression.eval(equation, upper) < 0) {
                while (Math.abs(EvaluateExpression.eval(equation, point)) > Eps) {
                    System.out.println(EvaluateExpression.eval(equation, point));
                    double nom = Precision.precision(lower * EvaluateExpression.eval(equation, upper) - upper * EvaluateExpression.eval(equation, lower), significant);
                    double dom = Precision.precision(EvaluateExpression.eval(equation, upper) - EvaluateExpression.eval(equation, lower), significant);
                    point = Precision.precision((nom) / (dom), significant);
                    if (EvaluateExpression.eval(equation, point) * EvaluateExpression.eval(equation, lower) > 0) {
                        lower = point;
                    } else if (EvaluateExpression.eval(equation, point) * EvaluateExpression.eval(equation, lower) < 0) {
                        upper = point;
                    }
                }

            } else {
                return "This function has no Roots in this interval";

            }
        }
        return Double.toString(point);
    }


}
