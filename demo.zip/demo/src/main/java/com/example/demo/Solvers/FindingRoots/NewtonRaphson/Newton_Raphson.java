package com.example.demo.Solvers.FindingRoots.NewtonRaphson;


import com.example.demo.DifferentiationLibrary.Function;
import com.example.demo.DifferentiationLibrary.differential.symbolic.Differentiator;
import com.example.demo.Evaluation.EvaluateExpression;
import com.example.demo.Solvers.Precision;

public class Newton_Raphson {
    public static String newton(String input, double x0, int iteration, double epslon, int prec) {
        Differentiator diff = new Differentiator();
        Function function = new Function(input);
        Function differentiation = diff.differentiate(function, true);
        double fraction = 0;
        int i = 0;
        double check = Precision.precision(EvaluateExpression.eval(differentiation.getEquation(), x0), prec);
        if (check == 0) {
            return "ُError";
        }
        double x1 = Precision.precision(x0 - (Precision.precision(Precision.precision(EvaluateExpression.eval(input, x0), prec) / Precision.precision(EvaluateExpression.eval(differentiation.getEquation(), x0), prec), prec)), prec);
        while (Precision.precision(Math.abs(((x1 - x0) / x1) * 100), prec) >= epslon && i <= iteration) {
            x0 = x1;
            fraction = Precision.precision(Precision.precision(EvaluateExpression.eval(input, x0), prec) / Precision.precision(EvaluateExpression.eval(differentiation.getEquation(), x0), prec), prec);
            x1 = Precision.precision(x0 - fraction, prec);
            i++;
        }
        System.out.println("the root is = " + Math.round(x1 * 100.0) / 100.0);
        double ans = Precision.precision((x1 * 100.0) / 100.0, prec);
        return ans + "";
    }

}
