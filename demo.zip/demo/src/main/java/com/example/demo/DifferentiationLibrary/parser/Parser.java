package com.example.demo.DifferentiationLibrary.parser;

public interface Parser<T, R> {
    R parse(T t);
}
