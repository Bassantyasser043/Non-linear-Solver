package com.example.demo.Evaluation;

import net.objecthunter.exp4j.ExpressionBuilder;
import net.objecthunter.exp4j.function.Function;
import org.springframework.stereotype.Component;

public class EvaluateExpression {
    public static double eval(String equation, double x) {
        Function ln = new Function("ln", 1) {
            @Override
            public double apply(double... args) {
                return Math.log(args[0]);
            }
        };
        net.objecthunter.exp4j.Expression expression = new ExpressionBuilder(equation)
                .function(ln)
                .variables("x")
                .build()
                .setVariable("x", x);

        double result = expression.evaluate();
        return result;
    }
}
