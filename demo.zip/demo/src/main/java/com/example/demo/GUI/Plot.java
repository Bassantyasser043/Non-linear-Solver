package com.example.demo.GUI;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

import com.example.demo.Evaluation.EvaluateExpression;
import org.math.plot.*;

public class Plot {
    public  Plot2DPanel plotG = new Plot2DPanel();

    public Plot() {
        JFrame frame = new JFrame("a plot panel");
        frame.setContentPane(plotG);
        frame.setVisible(true);
        frame.setSize(1000, 600);
        frame.getContentPane().setBackground(Color.decode("#878f99"));
        frame.setLocationRelativeTo(null);

    }

    public  void table(String equation, double x1, double x2) {
        double i = x1;
        int length = (int) (Math.abs((x1 - x2)) * 100);
        double[] x = new double[length];
        double[] y = new double[length];
        int count = 0;
        while (count < length) {
            x[count] = i;
            y[count] = EvaluateExpression.eval(equation, i);
            i = i + 0.01;
            count++;
        }
        plot(x, y);
    }

    public  void plot(double[] x, double[] y) {
        plotG.addLinePlot("my plot", x, y);
    }
}
