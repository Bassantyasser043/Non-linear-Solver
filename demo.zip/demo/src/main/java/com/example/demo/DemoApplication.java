package com.example.demo;

import com.example.demo.DifferentiationLibrary.Function;
import com.example.demo.DifferentiationLibrary.differential.symbolic.Differentiator;
import com.example.demo.Evaluation.CoefficientServices;
import com.example.demo.Evaluation.ValidateEquation;
import com.example.demo.GUI.GuiServices;
import com.example.demo.GUI.Plot;
import com.example.demo.Solvers.FindingRoots.Bisection.Bisection;
import com.example.demo.Solvers.FindingRoots.FalsePosition.FalsePosition;
import com.example.demo.Solvers.FindingRoots.FixedPoint.FixedPoint;
import com.example.demo.Solvers.FindingRoots.NewtonRaphson.Newton_Raphson;
import com.example.demo.Solvers.FindingRoots.SecantMethod.SecantMethod;
import com.example.demo.Solvers.SolvingSystemOflinearEquations.Gauss.GaussService;
import com.example.demo.Solvers.SolvingSystemOflinearEquations.LU.LUServices;
import com.example.demo.Solvers.SolvingSystemOflinearEquations.seidelAndJacobi.Jacobi;
import com.example.demo.Solvers.SolvingSystemOflinearEquations.seidelAndJacobi.Seidel;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

@SpringBootApplication
public class DemoApplication extends JFrame {

    public static void main(String[] args) {

        SpringApplication.run(DemoApplication.class, args);
        //declaring components
        GuiServices guiServices = new GuiServices();
        JFrame frame = new JFrame();
        JTextPane Variables = new JTextPane();
        JLabel label = new JLabel();
        JLabel method_of_solving = new JLabel();
        JLabel Variables_label = new JLabel();
        JLabel equations_label = new JLabel();
        JLabel output_label = new JLabel();
        JLabel runTime_label = new JLabel();
        JLabel matrix_label = new JLabel();
        JTextPane input = new JTextPane();
        JTextField output = new JTextField();
        JTextField runTime = new JTextField();
        JTextPane matrix = new JTextPane();
        JComboBox methods = new JComboBox(guiServices.manner);
        JButton solve = new JButton("Solve");
        JButton plot = new JButton("Plot");
        JButton setAttributes = new JButton("Set Attributes");
        Border border = BorderFactory.createLineBorder(Color.green, 3);
        JButton clear = new JButton("Clear");
        String path = "src/main/resources/Logo.png";
        ImageIcon image = new ImageIcon(path);

        // setting a label
        label.setText("Solve Equation");
        label.setForeground(Color.decode("#3e4444"));
        label.setFont(new Font("MV Boli", Font.PLAIN, 50));
        label.setHorizontalAlignment(JLabel.CENTER);
        label.setVerticalAlignment(JLabel.TOP);

        // adding text field for the input
        equations_label.setText("Equations");
        equations_label.setFont(new Font("Times New Roman", Font.PLAIN, 30));
        equations_label.setBounds(20, 230, 150, 50);
        input.setFont(new Font("Times New Roman", Font.PLAIN, 20));
        input.setBounds(150, 200, 725, 100);

        // adding text field for the output
        output_label.setText("Output");
        output_label.setFont(new Font("Times New Roman", Font.PLAIN, 30));
        output_label.setBounds(20, 450, 150, 50);
        output.setFont(new Font("Times New Roman", Font.PLAIN, 20));
        output.setBounds(150, 450, 725, 50);
        output.setEditable(false);

        // adding text field for matrix
        matrix_label.setText("Matrix");
        matrix_label.setFont(new Font("Times New Roman", Font.PLAIN, 30));
        matrix_label.setBounds(900, 100, 150, 50);
        matrix.setFont(new Font("Times New Roman", Font.PLAIN, 20));
        matrix.setBounds(900, 150, 400, 500);
        matrix.setEditable(false);

        // adding text field for the runtime
        runTime_label.setText("Run Time");
        runTime_label.setFont(new Font("Times New Roman", Font.PLAIN, 30));
        runTime_label.setBounds(20, 525, 150, 50);
        runTime.setFont(new Font("Times New Roman", Font.PLAIN, 20));
        runTime.setBounds(150, 525, 725, 50);
        runTime.setEditable(false);

        // adding text field for the Variables
        Variables_label.setText("Variables");
        Variables_label.setFont(new Font("Times New Roman", Font.PLAIN, 30));
        Variables_label.setBounds(20, 350, 150, 50);
        Variables.setFont(new Font("Times New Roman", Font.PLAIN, 20));
        Variables.setBounds(150, 350, 725, 50);

        // adding dropdown list
        method_of_solving.setText("Method");
        method_of_solving.setFont(new Font("Times New Roman", Font.PLAIN, 30));
        method_of_solving.setBounds(20, 100, 150, 50);
        methods.setFont(new Font("Times New Roman", Font.PLAIN, 20));
        methods.setBounds(150, 100, 300, 50);
        methods.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                guiServices.text = (String) methods.getSelectedItem();
                guiServices.type = guiServices.checkType(guiServices.text);
                if (guiServices.type == 2) {
                    Variables.setText("");
                    Variables.setEditable(false);
                    matrix.setVisible(false);
                    matrix_label.setVisible(false);
                } else {
                    Variables.setEditable(true);
                    matrix.setVisible(true);
                    matrix_label.setVisible(true);
                }
            }
        });
        // setting a button solve
        solve.setBounds(650, 600, 100, 50);
        solve.setBackground(Color.green);
        solve.setFont(new Font("Arial", Font.PLAIN, 20));
        solve.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                output.setText("");
                runTime.setText("");
                matrix.setText("");
                int numOfvariables = 0, rank;
                long startTime;
                boolean flag = true;
                //check the entered number of variables
                if (flag) {
                    //check if input is entered
                    if (input.getText().equals("")) {
                        guiServices.showError("  Please, Enter The Equations");
                    } else {
                        if (guiServices.type == 1) {
                            try {
                                numOfvariables = Integer.parseInt(Variables.getText());
                            } catch (NumberFormatException e1) {
                                guiServices.showError("Please, Enter a valid Integer");
                                flag = false;
                            }
                            //check if number of variables is entered
                            if (Variables.getText().equals("")) {
                                guiServices.showError("Enter the NUMBER of variables");
                            } else {
                                //check the vaidity of equations
                                CoefficientServices coefficientServices = new CoefficientServices(input.getText(), numOfvariables);
                                if (coefficientServices.valid) {
                                    //get the augmented, coefficients,and results matrices
                                    double[][] augmentedMatrix = coefficientServices.extract_coeff(Integer.parseInt(Variables.getText()));
                                    double[][] coefficientsMatrix = guiServices.getCoefficientMatrix(augmentedMatrix, numOfvariables);
                                    double[] resultsArray = guiServices.getResultsArray(augmentedMatrix, numOfvariables);
                                    double[] solution = {};
                                    //check the rank of the augmented matrix
                                    rank = coefficientServices.Rank(coefficientsMatrix, resultsArray, guiServices.g_precision);
                                    if (rank == -1) {
                                        output.setText("No solution");
                                        runTime.setText("");
                                        matrix.setText("");
                                    } else if (rank == 1) {
                                        output.setText("Infinite number of solutions");
                                        runTime.setText("");
                                        matrix.setText("");
                                    } else {
                                        //check which method to apply
                                        if (guiServices.text.equals("Gauss Elimination")) {
                                            GaussService gaussService = new GaussService();
                                            startTime = System.nanoTime();
                                            solution = gaussService.Gauss(coefficientsMatrix, resultsArray, guiServices.g_precision);
                                            String steps = guiServices.setMatrix(coefficientsMatrix);
                                            matrix.setText(steps);
                                        } else if (guiServices.text.equals("Gauss-Jordan")) {
                                            GaussService gaussService = new GaussService();
                                            startTime = System.nanoTime();
                                            solution = gaussService.Gauus_jorrdan(coefficientsMatrix, resultsArray, guiServices.g_precision);
                                            String steps = guiServices.setMatrix(coefficientsMatrix);
                                            matrix.setText(steps);
                                        } else if (guiServices.text.equals("LU Decomposition")) {
                                            LUServices luServices = new LUServices(numOfvariables, coefficientsMatrix, resultsArray, guiServices.g_precision);
                                            if (guiServices.lu_form == "Doolittle Form") {
                                                startTime = System.nanoTime();
                                                solution = luServices.Doolittle();
                                            } else {
                                                startTime = System.nanoTime();
                                                solution = luServices.Crout();
                                            }
                                            String steps = "L:\n" + guiServices.setMatrix(luServices.luResult.getL());
                                            steps += "U:\n";
                                            steps += guiServices.setMatrix(luServices.luResult.getU());
                                            matrix.setText(steps);
                                        } else if (guiServices.text.equals("Gauss-Seidil")) {
                                            Seidel seidel = new Seidel();
                                            startTime = System.nanoTime();
                                            solution = seidel.seidelMethod(augmentedMatrix, guiServices.g_initial_guess_values, guiServices.g_stop_condition, guiServices.g_stop_value, guiServices.g_precision);
                                            matrix.setText("");
                                            if (seidel.isDivergent) {
                                                output.setText(guiServices.turnIntoString(solution));
                                                guiServices.showError("       Diverges");
                                            }
                                        } else { //jacobi{
                                            Jacobi jacobi = new Jacobi();
                                            startTime = System.nanoTime();
                                            solution = jacobi.JacobiMethod(augmentedMatrix, guiServices.g_initial_guess_values, guiServices.g_stop_condition, guiServices.g_stop_value, guiServices.g_precision);
                                            matrix.setText("");
                                            if (jacobi.isDivergent) {
                                                output.setText(guiServices.turnIntoString(solution));
                                                guiServices.showError("       Diverges");
                                            }
                                        }
                                        long endTime = System.nanoTime();
                                        long totalTime = endTime - startTime;
                                        runTime.setText(totalTime + "");
                                        output.setText(guiServices.turnIntoString(solution));
                                    }
                                } else {
                                    output.setText("");
                                    guiServices.showError("Enter a proper format");

                                }
                            }
                        } else {
                            ValidateEquation validateEquation = new ValidateEquation();

                            try {
                                String equation = validateEquation.fixExpression(input.getText());
                                guiServices.equation = equation;
                                String res = "X = ";
                                String ans="";
                                switch (guiServices.text) {
                                    case "Bisection":
                                        startTime = System.nanoTime();
                                        res += Bisection.bisection(guiServices.xu_value, guiServices.xl_value, equation, guiServices.g_stop_condition, guiServices.g_stop_value, guiServices.g_precision);
                                        break;
                                    case "False-Position":
                                        startTime = System.nanoTime();
                                        res += FalsePosition.False_position(equation, guiServices.g_stop_condition, guiServices.g_stop_value, guiServices.xl_value, guiServices.xu_value, guiServices.g_precision);
                                        break;
                                    case "Fixed Point":
                                        startTime = System.nanoTime();
                                        try {
                                            res += FixedPoint.FixedPoint(guiServices.initial, equation, guiServices.noOfiterations, guiServices.error, guiServices.g_precision);
                                        } catch (Exception e3) {
                                            res += "Diverges";
                                        }
                                        break;
                                    case "Newton-Raphson":
                                        startTime = System.nanoTime();
                                        try {
                                            ans = Newton_Raphson.newton(equation, guiServices.initial, guiServices.noOfiterations, guiServices.error, guiServices.g_precision);
                                        } catch (Exception e1) {
                                            ans = "Diverges";
                                        }
                                        if (ans.equals("Error") || ans.equals("-Infinity") || ans.equals("Infinity")) {
                                            throw new NullPointerException();
                                        } else res += ans;
                                        break;
                                    case "Secant Method":
                                        startTime = System.nanoTime();
                                        ans += SecantMethod.SecantMethod(guiServices.g_precision, guiServices.g_stop_condition, guiServices.g_stop_value, guiServices.xl_value, guiServices.xu_value, equation);
                                        if(ans.equals("NaN")) ans = "Diverges";
                                        res += ans;
                                        break;
                                    default:
                                        throw new Exception();
                                }
                                long endTime = System.nanoTime();
                                long totalTime = endTime - startTime;
                                runTime.setText(totalTime + "");
                                output.setText(res);

                            } catch (NullPointerException nP) {
                                guiServices.showError("Try another initial guess");
                                Variables.setText("");
                                output.setText("");
                                runTime.setText("");
                                matrix.setText("");

                            } catch (Exception e2) {
                                System.out.println(e2);
                                System.out.println(e2.getStackTrace());
                                guiServices.showError("Enter a proper format");
                                Variables.setText("");
                                output.setText("");
                                runTime.setText("");
                                matrix.setText("");
                            }
                        }
                    }
                }
            }
        });


        // plot button
        plot.setBounds(350, 600, 100, 50);
        plot.setBackground(Color.green);
        plot.setFont(new Font("Arial", Font.PLAIN, 20));
        plot.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (guiServices.equation == null) return;
                Plot plotting = new Plot();
                Differentiator diff = new Differentiator();
                Function function = new Function(guiServices.equation);
                Function differentiation = diff.differentiate(function, true);
                switch (guiServices.text) {
                    case "Bisection":
                    case "False-Position":
                        plotting.table(guiServices.equation, guiServices.xl_value - 50, guiServices.xu_value + 50);
                        break;
                    case "Fixed Point":
                        plotting.table(guiServices.equation, guiServices.initial - 50, guiServices.initial + 50);
                        plotting.table("x", guiServices.initial - 50, guiServices.initial + 50);
                        break;
                    case "Newton-Raphson":
                        plotting.table(guiServices.equation, guiServices.initial - 50, guiServices.initial + 50);
                        plotting.table(differentiation.getEquation(), guiServices.initial - 50, guiServices.initial + 50);
                        break;
                    case "Secant Method":
                        plotting.table(guiServices.equation, guiServices.xu_value - 50, guiServices.xu_value + 50);
                        plotting.table(differentiation.getEquation(), guiServices.xu_value - 50, guiServices.xu_value + 50);
                        break;
                }
            }
        });

        // setting button setAttributes
        setAttributes.setBounds(450, 600, 200, 50);
        setAttributes.setBackground(Color.green);
        setAttributes.setFont(new Font("Arial", Font.PLAIN, 20));
        setAttributes.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                guiServices.showParameters(guiServices.text);
            }
        });

        // setting button clear
        clear.setBounds(750, 600, 100, 50);
        clear.setBackground(Color.green);
        clear.setFont(new Font("Arial", Font.PLAIN, 20));
        clear.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                methods.setSelectedItem(guiServices.manner[0]);
                input.setText("");
                Variables.setText("");
                output.setText("");
                runTime.setText("");
                matrix.setText("");
            }
        });

        // adding elements to the frame
        frame.add(methods);
        frame.add(method_of_solving);
        frame.add(input);
        frame.add(equations_label);
        frame.add(output);
        frame.add(output_label);
        frame.add(runTime);
        frame.add(runTime_label);
        frame.add(matrix);
        frame.add(matrix_label);
        frame.add(Variables);
        frame.add(Variables_label);
        frame.add(setAttributes);
        frame.add(solve);
        frame.add(plot);
        frame.add(clear);
        frame.add(label);

        // setting border
        label.setBorder(border);

        // to set a logo
        frame.setIconImage(image.getImage());

        // Setting the frame
        frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
        frame.setTitle("Equation Solver");
        frame.setSize(1000, 600);
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setResizable(false);
        frame.getContentPane().setBackground(Color.decode("#878f99"));
    }
}
