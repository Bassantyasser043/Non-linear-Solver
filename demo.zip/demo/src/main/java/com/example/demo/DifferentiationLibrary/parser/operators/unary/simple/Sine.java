package com.example.demo.DifferentiationLibrary.parser.operators.unary.simple;

import com.example.demo.DifferentiationLibrary.parser.nodes.NodeConstant;
import com.example.demo.DifferentiationLibrary.parser.nodes.NodeFactory;
import com.example.demo.DifferentiationLibrary.parser.operators.unary.TrigOperator;

public class Sine extends TrigOperator {

    @Override
    public String[] getAliases() {
        return new String[]{"sin", "sine"};
    }

    @Override
    public NodeConstant getResult(double num) {
        double result = Math.sin(num);
        return NodeFactory.createNodeNumberFrom(result);
    }

    @Override
    public String toLongString() {
        return "sine";
    }

    @Override
    public String toString() {
        return "sin";
    }
}
