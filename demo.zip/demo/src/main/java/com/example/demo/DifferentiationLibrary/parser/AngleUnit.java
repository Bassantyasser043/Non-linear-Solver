package com.example.demo.DifferentiationLibrary.parser;

public enum AngleUnit
{
	Degrees, Radians, Gradians;
}
