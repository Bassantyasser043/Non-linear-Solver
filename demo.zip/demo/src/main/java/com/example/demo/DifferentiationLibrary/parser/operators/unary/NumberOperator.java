package com.example.demo.DifferentiationLibrary.parser.operators.unary;

import com.example.demo.DifferentiationLibrary.parser.nodes.NodeConstant;
import com.example.demo.DifferentiationLibrary.parser.nodes.NodeNumber;
import com.example.demo.DifferentiationLibrary.parser.operators.UnaryOperator;

import java.util.function.Function;

public abstract class NumberOperator extends UnaryOperator {

    @Override
    public int getPrecedence() {
        return 2;
    }

    @Override
    public NodeConstant toResult(NodeConstant arg1) {
        return arg1.applyUniFunc(getFunc());
    }

    protected abstract Function<NodeNumber, NodeConstant> getFunc();
}
