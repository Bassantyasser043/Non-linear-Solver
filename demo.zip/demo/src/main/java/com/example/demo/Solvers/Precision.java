package com.example.demo.Solvers;

import java.math.BigDecimal;
import java.math.RoundingMode;

public class Precision {
    public static double precision(double num, int precision) {
        if(precision==-1){
            return num;
        }
        BigDecimal round = new BigDecimal(Double.toString(num));

        round = round.setScale(precision, RoundingMode.HALF_UP);

        return round.doubleValue();

    }
}
