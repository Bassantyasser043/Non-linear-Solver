package com.example.demo.DifferentiationLibrary;

import com.example.demo.Evaluation.EvaluateExpression;
import com.example.demo.Evaluation.ValidateEquation;
import com.example.demo.DifferentiationLibrary.differential.symbolic.Differentiator;

import java.util.Scanner;

public class Trial {
    public static void main(String[] args) {
        ValidateEquation validateEquation = new ValidateEquation();
        Scanner sc = new Scanner(System.in);
        String eq;
        while (true) {
            eq = sc.nextLine();
            try {
                eq = validateEquation.fixExpression(eq);
                Function function = new Function(eq);
                Differentiator differentiator = new Differentiator();
                Function derivative = differentiator.differentiate(function, true);
                System.out.println(EvaluateExpression.eval(derivative.getEquation(), 0));
                System.out.println(derivative.getEquation());
            } catch (Exception e) {
                System.out.println("Enter a valid eq");
            }
        }


    }
}
