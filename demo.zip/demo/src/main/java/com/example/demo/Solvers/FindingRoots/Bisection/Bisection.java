package com.example.demo.Solvers.FindingRoots.Bisection;

import com.example.demo.Evaluation.EvaluateExpression;
import com.example.demo.Solvers.Precision;

import java.lang.Math;

public class Bisection {

    public static String bisection(double xu, double xl, String equation, String condition, double stop, int precision) {
        double xr = 0;
        double fxr = EvaluateExpression.eval(equation, xu);
        double fxl = EvaluateExpression.eval(equation, xl);
        double ea = 10;
        int i = 0;
        if (fxr * fxl < 0 && xu > xl) {
            if (condition.equals("Number of Iterations")) {
                while (i < stop) {
                    xr = (xu + xl) / 2;
                    fxr = EvaluateExpression.eval(equation, xr);
                    fxl = EvaluateExpression.eval(equation, xl);
                    if (fxr * fxl < 0) {
                        xu = Precision.precision(xr,precision);
                    } else if (fxr * fxl > 0) {
                        xl = Precision.precision(xr,precision);
                    } else if (fxl * fxr == 0) {
                        break;
                    }
                    i++;
                }
            } else {
                while (ea > stop) {
                    xr = (xu + xl) / 2;
                    fxr = EvaluateExpression.eval(equation, xr);
                    fxl = EvaluateExpression.eval(equation, xl);
                    if (fxr * fxl < 0) {
                        xu = Precision.precision(xr,precision);
                    } else if (fxr * fxl > 0) {
                        xl = Precision.precision(xr,precision);
                    } else if (fxl * fxr == 0) {
                        break;
                    }
                    ea = Math.abs((xu - xl) / xl);
                    i++;
                }
            }
            return Precision.precision(xr,precision)+"";
        }
        else {
            return "This function has no Roots in this interval";
        }
    }
}

