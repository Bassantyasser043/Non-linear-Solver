package com.example.demo.Solvers.FindingRoots.FixedPoint;

import com.example.demo.DifferentiationLibrary.Function;
import com.example.demo.DifferentiationLibrary.differential.symbolic.Differentiator;
import com.example.demo.Evaluation.EvaluateExpression;
import com.example.demo.Solvers.Precision;


public class FixedPoint {

    public static String FixedPoint(double x0, String input, int iterationlimit, double epslon, int prec) {
        String gxfunc = input + "+x";
        Differentiator diff = new Differentiator();
        Function function = new Function(gxfunc);

        Function differentiation = diff.differentiate(function, true);
        double diffgx = EvaluateExpression.eval(differentiation.getEquation(), x0);
        System.out.println(diffgx);
        if (Math.abs(diffgx) > 1) {
            if (diffgx > 0) {
                return "diverge monotonic";
            } else {
                return "diverge oscillate";
            }
        }
        System.out.println(gxfunc);
        double xnew = 0;
        int i = 0;
        xnew = Precision.precision(EvaluateExpression.eval(gxfunc, x0), prec);
        while (Precision.precision(Math.abs((xnew - x0) / xnew) * 100, prec) >= epslon && i <= iterationlimit) {
            x0 = xnew;
            xnew = Precision.precision(EvaluateExpression.eval(gxfunc, x0), prec);
            i++;
            if (xnew == 0) {
                break;
            }
        }

        return xnew + "";
    }

}

