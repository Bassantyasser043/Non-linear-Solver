package com.example.demo.Solvers.SolvingSystemOflinearEquations.LU;

public interface LUServicesI {
    public double[] Doolittle();

    public double[] Crout();


}
