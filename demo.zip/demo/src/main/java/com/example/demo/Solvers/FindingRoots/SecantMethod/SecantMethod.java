package com.example.demo.Solvers.FindingRoots.SecantMethod;

import com.example.demo.Evaluation.EvaluateExpression;
import com.example.demo.GUI.Plot;
import com.example.demo.Solvers.Precision;

import java.math.BigDecimal;
import java.math.RoundingMode;

public class SecantMethod {
    // public String fun;


    //Function to evaluate the required root by the rule
    public static double EvaluateRoot(double Xj, double Xi, double Fxj, double Fxi, int precision) {
        double X;
        X = Precision.precision(Xi, precision) - (Precision.precision(Precision.precision(Fxi * (Xi - Xj), precision) / Precision.precision(Fxi - Fxj, precision), precision));
        return Precision.precision(X, precision);
    }

    //Function t Evaluate the absolute relative error after each step
    public static double EvaluateRelativeError(double X, double Xi, int precision) throws NumberFormatException {
        double Ea;
        Ea = Math.abs((Precision.precision(X, precision) - Precision.precision(Xi, precision)) / Precision.precision(X, precision)) * 100;
        return Precision.precision(Ea, precision);

    }


    public static double SecantMethod(int precision, String choice, double value, double Xj, double Xi, String function) {
        //value : number of a maximum iterations or Eps based on the choice of the user
        // fun: the function that needs to get roots of it
        //Xj : X(i-1)
        //Xi : Xi
        //X  : X(i+1) >> the required root
        double X = 0;
        double Fxj, Fxi;
        double MaxIterations = 0;
        double Eps = 0, E = 0;

        switch (choice) {
            case "Number of Iterations":
                MaxIterations = value;
                break;
            case "Absolute Relative Error":
                Eps = value;
                break;
        }
       // Plot.table(function, Xj, Xi);  ///Plottt
        if (MaxIterations == value) {
            for (int i = 0; i < MaxIterations; ++i) {
                Fxj = EvaluateExpression.eval(function, Precision.precision(Xj, precision));
                Fxi = EvaluateExpression.eval(function, Precision.precision(Xi, precision));
                X = EvaluateRoot(Xj, Xi, Fxj, Fxi, precision);
                E = EvaluateRelativeError(X, Xi, precision);
                System.out.println("root= ");
                System.out.println(X);
                System.out.println("absolute relative error= ");
                System.out.println(E);
                Xj = Precision.precision(Xi, precision);
                Xi = X;
                if(E == 0) break;
            }

        } else if (Eps == value) {

            Fxj = EvaluateExpression.eval(function, Precision.precision(Xj, precision));
            Fxi = EvaluateExpression.eval(function, Precision.precision(Xi, precision));
            X = EvaluateRoot(Xj, Xi, Fxj, Fxi, precision);
            E = EvaluateRelativeError(X, Xi, precision);
            while (E > Eps) {
                Fxj = EvaluateExpression.eval(function, Precision.precision(Xj, precision));
                Fxi = EvaluateExpression.eval(function, Precision.precision(Xi, precision));
                X = EvaluateRoot(Xj, Xi, Fxj, Fxi, precision);
                E = EvaluateRelativeError(X, Xi, precision);

                System.out.println("root= ");
                System.out.println(X);
                System.out.println("absolute relative error= ");
                System.out.println(E);

                Xj = Precision.precision(Xi, precision);
                Xi = X;
                if(E == 0) break;

            }

            System.out.println("final root= ");
            return Precision.precision(X, precision);

        }

        System.out.println("final root= ");
        return Precision.precision(X, precision);
    }
}