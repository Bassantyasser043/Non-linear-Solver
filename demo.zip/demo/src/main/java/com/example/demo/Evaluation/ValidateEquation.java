package com.example.demo.Evaluation;

import org.springframework.stereotype.Component;

@Component
public class ValidateEquation {

    public String validateParentheses(String equation) {
        try {
            equation = getEquation(equation);
            EvaluateExpression.eval(equation, 0);
        } catch (Exception e) {
            return null;
        }
        int i = 0;
        while (i < equation.length()) {
            if ((equation.charAt(i) == 'i' && equation.charAt(i + 1) == 'n' || equation.charAt(i) == 'o' && equation.charAt(i + 1) == 's' || equation.charAt(i) == 'e' && equation.charAt(i + 1) == '^') && equation.charAt(i + 2) != '(') {
                return null;
            }
            i++;
        }
        return equation;
    }

    public String getEquation(String equation) throws Exception {
        String[] wholeEquation = equation.split("=");
        if (wholeEquation.length != 2) throw new Exception();
        String res = wholeEquation[0];
        if (wholeEquation[1].equals("0")) return res;
        res = res + "-(" + wholeEquation[1] + ")";
        return res;
    }

    public String fixExpression(String equation) throws Exception {
        equation = validateParentheses(equation);
        if (equation==null) throw new Exception();
        StringBuilder expression = new StringBuilder(equation);
        int i = 0;
        while (i + 1 < expression.length()) {
            if (((expression.charAt(i) <= '9' && expression.charAt(i) >= '0') || (expression.charAt(i) == ')')) && ((expression.charAt(i + 1) == 'x') || expression.charAt(i + 1) == 's' || expression.charAt(i + 1) == 'c' || expression.charAt(i + 1) == 'e')) {
                expression.insert(i + 1, '*');
            }
            i++;
        }
        return expression.toString();
    }
}
