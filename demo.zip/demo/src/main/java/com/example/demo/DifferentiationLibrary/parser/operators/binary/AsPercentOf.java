package com.example.demo.DifferentiationLibrary.parser.operators.binary;

import com.example.demo.DifferentiationLibrary.parser.nodes.NodeConstant;
import com.example.demo.DifferentiationLibrary.parser.nodes.NodeFactory;
import com.example.demo.DifferentiationLibrary.parser.nodes.NodeNumber;
import com.example.demo.DifferentiationLibrary.parser.nodes.NodePercent;
import com.example.demo.DifferentiationLibrary.parser.operators.BinaryOperator;

public class AsPercentOf extends BinaryOperator
{
	@Override
	public String[] getAliases()
	{
		return new String[] { "as%of", "aspercentof", "aspercentageof", "asa%of", "asapercentof",
				"asapercentageof" };
	}

	@Override
	public int getPrecedence()
	{
		return 3;
	}

	@Override
	public String toLongString()
	{
		return "as a percentage of";
	}

	@Override
	public NodeConstant toResult(NodeConstant arg1, NodeConstant arg2)
	{
		NodeNumber a = arg1.getTransformer().toNodeNumber();
		NodeNumber b = arg2.getTransformer().toNodeNumber();
		NodeNumber hundred = NodeFactory.createNodeNumberFrom(100.0);

		return new NodePercent(a.divide(b).multiply(hundred).getTransformer().toNodeNumber().doubleValue());
	}

	@Override
	public String toString()
	{
		return "as % of";
	}

}
